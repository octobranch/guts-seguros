/* Lightweight progressive enhancement. No analytics, cookies or server-side storage. */
(() => {
  'use strict';
  const toggle = document.querySelector('[data-menu-toggle]');
  const nav = document.querySelector('#primary-nav');
  if (toggle && nav) {
    const closeNav = () => {
      document.body.classList.remove('nav-open');
      toggle.setAttribute('aria-expanded', 'false');
    };
    toggle.addEventListener('click', () => {
      const isOpen = document.body.classList.toggle('nav-open');
      toggle.setAttribute('aria-expanded', String(isOpen));
    });
    nav.querySelectorAll('a').forEach(link => link.addEventListener('click', closeNav));
    document.addEventListener('keydown', event => { if (event.key === 'Escape') closeNav(); });
    document.addEventListener('click', event => {
      if (!nav.contains(event.target) && !toggle.contains(event.target)) closeNav();
    });
  }

  const form = document.querySelector('[data-mailto-form]');
  if (!form) return;
  const serviceSelect = form.querySelector('[name="service"]');
  document.querySelectorAll('[data-service]').forEach(link => {
    link.addEventListener('click', () => {
      const service = link.getAttribute('data-service');
      if (serviceSelect && [...serviceSelect.options].some(option => option.value === service)) {
        serviceSelect.value = service;
      }
    });
  });
  form.addEventListener('submit', event => {
    event.preventDefault();
    if (!form.reportValidity()) return;
    const values = new FormData(form);
    const en = form.dataset.locale === 'en';
    const label = en ? {
      subject: 'Insurance consultation request', name: 'Name', email: 'Email', phone: 'Phone',
      service: 'Interested in', message: 'Message', source: 'Source'
    } : {
      subject: 'Solicitud de asesoría de seguros', name: 'Nombre', email: 'Correo', phone: 'Teléfono',
      service: 'Interés', message: 'Mensaje', source: 'Origen'
    };
    const selectedLabel = serviceSelect?.selectedOptions[0]?.textContent.trim() || '';
    const subject = `${label.subject} · ${selectedLabel}`;
    const body = [
      `${label.name}: ${String(values.get('name') || '').trim()}`,
      `${label.email}: ${String(values.get('email') || '').trim()}`,
      `${label.phone}: ${String(values.get('phone') || '').trim() || '—'}`,
      `${label.service}: ${selectedLabel}`,
      '',
      `${label.message}:`,
      String(values.get('message') || '').trim() || '—',
      '',
      `${label.source}: ${window.location.href}`
    ].join('\n');
    const url = `mailto:contacto@guts.mx?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    window.location.href = url;
  });
})();
