# Estrategia SEO, SEO local y AEO — GUTS Seguros

## Arquitectura de búsqueda

| Idioma | Keyword principal | Intención dominante | URL |
|---|---|---|---|
| ES-MX | asesores de seguros en Cancún | Comercial / local / contacto | `https://www.guts.mx/` |
| EN | insurance advisors in Cancun | Commercial / local / consultation | `https://www.guts.mx/en/` |

Las keywords no implican volúmenes de búsqueda comprobados. La priorización se basa en relevancia del servicio y de la intención del usuario. Confirmar con Search Console y Keyword Planner.

### ES: grupos secundarios

- **Asesoría local:** agente de seguros en Cancún; agencia de seguros en Cancún; asesoría de seguros en Cancún; despacho de seguros.
- **Vida:** seguro de vida en Cancún; cotizar seguro de vida; seguro de vida con ahorro; cuánto cuesta un seguro de vida.
- **GMM:** seguro de gastos médicos mayores en Cancún; cotizar GMM; deducible y coaseguro; qué cubre un seguro de gastos médicos mayores.
- **Educación/ahorro:** seguro educativo para hijos; plan de ahorro educativo; seguros de ahorro; seguro de vida con ahorro.
- **Empresa:** seguro de persona clave; seguro de hombre clave; protección financiera para empresas.

### EN: grupos secundarios, escritos para inglés natural

- **Local advice:** insurance advisor Cancun; insurance agents in Cancun; insurance brokers Cancun (usar esta variante solo si la clasificación profesional es correcta).
- **Life:** life insurance in Cancun; life insurance in Mexico; life insurance cost Mexico; life insurance with savings.
- **Medical:** major medical insurance Mexico; medical insurance in Cancun; health insurance advice in Mexico; deductibles and coinsurance in Mexico.
- **Goals / business:** education savings insurance; savings insurance plans Mexico; key person insurance Mexico.

**No se promete cobertura internacional, expat insurance, US insurance, cobertura para turistas o atención en inglés certificada** sin validación de la empresa. El idioma del sitio no implica elegibilidad para pólizas específicas.

## Intenciones cubiertas por sección

| Sección HTML | Intención | Elemento SEO/AEO |
|---|---|---|
| Hero / H1 | Buscar asesor local | Keyword principal + entidad + ciudad |
| Servicios / H2 / H3 | Investigar coberturas | Cinco tipos de seguros con listas explícitas |
| Tabla de necesidades | Comparación | Respuesta concisa según caso de uso |
| Proceso / `ol` | Evaluar un asesor | Pasos claros |
| Sobre GUTS | Verificar confianza | Descripción de la entidad; sin claims inventados |
| Glosario / `dl` | Comprender terminología | Definiciones naturales para usuarios e IA |
| FAQ / `details` | Resolver objeciones | Respuestas visibles y accesibles |
| Contacto | Convertir / consultar | Teléfono, email, dirección y llamada a la acción |

## Etiquetado e internacionalización

- Un H1 por página, encabezados H2 para secciones y H3 para productos/pasos.
- Etiquetas `lang="es-MX"` y `lang="en"`.
- Títulos, descripciones y contenidos **diferentes por idioma**; no traducción automática literal.
- `canonical` autocanónico; `hreflang` bidireccional y `x-default`.
- Schema.org `InsuranceAgency`, `WebSite`, `WebPage` en JSON-LD. Solo datos publicados y sin ratings falsos.
- `robots.txt` y sitemap XML con las variantes.
- Preguntas y respuestas en HTML. **No** se incluye `FAQPage` para buscar rich results: se prioriza el contenido útil, no un resultado enriquecido garantizado.
- Imágenes ilustrativas de banco, textos ALT descriptivos, `loading="lazy"` bajo el primer viewport; foto principal prioritaria.

## Próximas mediciones

1. Search Console: impresiones, clics, consultas sin marca por idioma, indexación y CTR.
2. Perfil de Negocio: visibilidad local, llamadas y clics.
3. Conversión: clics en teléfono/email y solicitudes; si se integra backend, leads reales con consentimiento.
4. Calidad técnica: LCP, INP, CLS, accesibilidad, distribución móvil.
5. Si un servicio capta demanda consistente, evaluar páginas de servicio independientes con contenido original, no páginas thin/duplicadas.

**Una landing optimizada no garantiza aparecer en la primera página de Google o ser citada por asistentes de IA.**
