# Banco de imágenes y licencias

La plantilla utiliza **fotografías de Unsplash**, enlazadas a través del CDN `images.unsplash.com`. Las fotografías son ilustrativas: **no representan empleados, clientes, instalaciones ni casos reales de GUTS**.

| Uso en la página | URL de origen | Fotógrafo | Archivo externo |
|---|---|---|---|
| Fotografía principal, familia | https://unsplash.com/photos/a-happy-family-of-three-sitting-on-a-couch-tdkQ_CLYtCc | Vitaly Gariev | `photo-1758687126864-96b61e1b3af0` |
| Vida/planificación familiar | https://unsplash.com/photos/mother-and-son-smiling-on-a-couch-tSwr_HGh0kQ | Vitaly Gariev | `photo-1758598737810-7489fde716af` |
| Salud / consulta médica | https://unsplash.com/photos/doctor-checks-patients-blood-pressure-with-stethoscope-NDOYHZ_98Rw | Vitaly Gariev | `photo-1758691462123-8a17ae95d203` |
| Conversación / asesoría | https://unsplash.com/photos/three-people-in-a-business-meeting-discussing-documents-1uf2JCPFAkU | Vitaly Gariev | `photo-1758518727077-ffb66ffccced` |

Licencia general: https://unsplash.com/license — permite su uso en proyectos comerciales y no comerciales, sin requerir atribución; se agradece atribuir. Verificar derechos de terceros si existen personas, marcas u obras identificables en una composición.

**Requisito de conexión:** las imágenes se sirven remotamente, por lo que no están incluidas en el ZIP y requieren conexión a Unsplash. Para servirlas desde el dominio propio, visita los enlaces de origen, descarga legalmente los archivos y sustituye en ambos HTML las URLs por rutas `assets/img/…`. Después ajusta las dimensiones y convierte a formatos optimizados (AVIF/WebP) para mejorar LCP y minimizar solicitudes de terceros.

Los archivos `guts-logo.webp`, `guts-logo.png`, `social-cover.jpg`, `social-cover-en.jpg` y `favicon.svg` **sí se incluyen localmente**; están derivados del logotipo proporcionado por el cliente, sin cambiar su identidad tipográfica.
