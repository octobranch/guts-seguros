# GUTS Seguros — Landing bilingüe SEO/AEO

Landing estática HTML5, sin frameworks ni proceso de compilación. **Español mexicano e inglés redactados de manera independiente**, con contenido específico para su intención comercial. La identidad gráfica procede del logotipo facilitado por el cliente.

## Estructura

```text
/
├── index.html                        # Español — https://www.guts.mx/
├── en/index.html                     # Inglés — https://www.guts.mx/en/
├── aviso-de-privacidad/index.html    # Aviso legal en español (requiere revisión)
├── en/privacy/index.html            # Traducción informativa en inglés (requiere revisión)
├── assets/
│   ├── css/styles.css                # Estilos y responsive
│   ├── js/main.js                    # Menú móvil y formulario mailto
│   └── img/
│       ├── guts-logo-original.png   # Logo fuente original del cliente
│       ├── guts-logo.webp           # Logo optimizado del archivo proporcionado
│       ├── guts-logo.png            # Variante PNG para Schema
│       ├── favicon.svg
│       ├── social-cover.jpg
│       └── social-cover-en.jpg
├── robots.txt
├── sitemap.xml
├── SEO-STRATEGY.md
├── IMAGE-SOURCES.md
└── .gitignore
```

## Probar localmente

Desde la raíz del proyecto:

```sh
python3 -m http.server 8080
```

Abre `http://localhost:8080/` y `http://localhost:8080/en/`. Los estilos y el JavaScript son locales; **las fotografías de Unsplash se cargan desde su CDN** y requieren conexión a internet. Los recursos fotográficos no se redistribuyen en el archivo ZIP. Se pueden descargar y servir localmente antes de producción; sus páginas de origen están en `IMAGE-SOURCES.md`.

## Publicar en GitHub Pages

1. Crea un repositorio y sube todo el contenido de esta carpeta a la **raíz** de la rama que publiques (por ejemplo, `main`).
2. Activa **Settings → Pages → Deploy from a branch**, elige rama y `/ (root)`.
3. Configura dominio personalizado `www.guts.mx` **solo si controlas el dominio y preparaste su DNS**; antes de apuntar DNS revisa que no interrumpas el sitio actual.
4. Comprueba HTTPS, resolución `www` y sin `www`, redirecciones y URL canónica. Los `<link rel="canonical">`, `hreflang`, `sitemap.xml`, Open Graph y Schema están preparados para **https://www.guts.mx/**. Si el canonical real será `https://guts.mx/`, cambia las referencias de forma consistente en todos los archivos.
5. Valida los metadatos y el marcado en Search Console y Rich Results Test, envía el sitemap y prueba ambas URLs públicamente.

**Importante:** publicar en un subdirectorio `usuario.github.io/repositorio` sirve para previsualizar, pero los metadatos canónicos apuntan al dominio final (correcto para la publicación definitiva). Para una vista preliminar no se debe interpretar el estado de indexación en Google como el de producción.

## Contacto y formulario

- Teléfono publicado: +52 (241) 112 3580 (verifica que es el número de contacto vigente).
- Email publicado: contacto@guts.mx.
- `assets/js/main.js` construye un enlace `mailto:` a partir de los datos del formulario y abre la aplicación de correo del visitante. **No guarda ni envía datos a un servidor.**
- Si se necesita capturar prospectos sin aplicación de correo, integra una API/servicio de formularios, valida en backend, implementa prevención de spam, protección de datos y estados de éxito/error antes del lanzamiento. No simules un formulario conectado.

## Antes de publicar (obligatorio revisar)

- [ ] Confirmar si `www.guts.mx` es la versión canónica final.
- [ ] Confirmar teléfono, email, dirección, horarios, alcance real de servicios e idioma de atención.
- [ ] Revisar con GUTS/CNSF la forma de describir la intermediación y credenciales de los agentes; agregar acreditaciones **solo si están verificadas**.
- [ ] **Revisión jurídica del aviso de privacidad:** se incorporó una versión maquetada del aviso que estaba publicado en guts.mx, sin sustituir una revisión legal. Comprobar que cumple obligaciones, recabación real y consentimiento aplicable. La versión inglesa tiene una traducción orientativa del aviso y remite al original español.
- [ ] Probar menú móvil, formulario `mailto:`, enlaces, imágenes y accesibilidad en dispositivos reales.
- [ ] Considerar alojar las fotos localmente y añadir una política de privacidad/cookies adecuada según los servicios usados.
- [ ] Configurar Search Console, medición de eventos/consultas **con el consentimiento legal necesario**, y verificar Google Business Profile.
- [ ] Medir rendimiento en dispositivos reales con PageSpeed Insights, imágenes de mayor peso y Core Web Vitals. No se promete una posición específica en Google.

## Enlaces de referencia

- Google Search: https://developers.google.com/search/docs/specialty/international/localized-versions
- Schema.org: https://schema.org/InsuranceAgency
- Licencia de imágenes: https://unsplash.com/license
